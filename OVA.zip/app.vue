<template>
  <div>
    <NuxtLayout>
      <NuxtPage />
    </NuxtLayout>
  </div>
  <div>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Libre+Bodoni:ital,wght@0,400..700;1,400..700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">
    <footer class="footer">
      <div class="footer-content">
        <div class="footer-logo">
          <img 
            class="footer-image" 
            src="https://th.bing.com/th/id/R.0cee4c4e109e44560fe5dcc2b6cf01fb?rik=boK9Vp1Gr6rJ1A&pid=ImgRaw&r=0" 
            alt="Logo del OVA"
          />
          <h1>OVA Desarrollo Web</h1>
        </div>
        <div class="footer-text">
          <p>
            &copy; 2024 OVA Introducción al Desarrollo Web. Todos los derechos reservados. 
          </p>
          <p>
            Este sitio fue creado con fines educativos para enseñar los fundamentos del desarrollo web. 
          </p>
          <p>
            Diseñado por: <strong>Luis Blanchar</strong> y <strong>Edgar Zambrano</strong>.
          </p>
        </div>
      </div>
      <div class="footer-bottom">
        <p>¡Sigue aprendiendo y creando cosas asombrosas en la web!</p>
      </div>
    </footer>
  </div>
</template>


<style>
* {
  font-family: "Poppins", sans-serif;
  box-sizing: border-box;
}

.footer {
  background: linear-gradient(135deg, #1e293b, #0f172a); /* Gradiente moderno */
  color: #f8fafc;
  padding: 40px 20px;
  margin-top: 40px;
  border-top: 4px solid #2563eb;
  box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.2); /* Sombra elegante */
}

.footer-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  max-width: 1200px;
  margin: 0 auto;
  flex-wrap: wrap;
  gap: 20px;
}

.footer-logo {
  display: flex;
  align-items: center;
  gap: 15px;
}

.footer-image {
  width: 60px;
  height: auto;
  border-radius: 50%;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); /* Sombra para destacar el logo */
  transition: transform 0.3s ease;
}

.footer-image:hover {
  transform: scale(1.1); /* Efecto hover en la imagen */
}

.footer-logo h1 {
  font-size: 1.5rem;
  font-weight: 600;
  margin: 0;
}

.footer-text {
  font-size: 0.95rem;
  line-height: 1.8;
  max-width: 600px;
}

.footer-text strong {
  color: #3b82f6; /* Resalta los nombres */
}

.footer-bottom {
  text-align: center;
  margin-top: 20px;
  font-size: 0.85rem;
  color: #94a3b8;
  padding-top: 10px;
  border-top: 1px solid rgba(255, 255, 255, 0.1);
}

.footer-bottom p {
  margin: 0;
}

@media (max-width: 768px) {
  .footer-content {
    flex-direction: column;
    text-align: center;
  }

  .footer-logo {
    justify-content: center;
  }

  .footer-text {
    max-width: 100%;
  }
}
</style>
