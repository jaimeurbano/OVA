<template>
  <nav class="navbar" :class="{ 'navbar-scrolled': isScrolled }">
    <div class="navbar-container">
      <div class="navbar-logo">
        <span class="logo-text">&lt;/&gt;</span>
        <span class="logo-name">WebDev</span>
      </div>

      <div class="navbar-menu" :class="{ 'active': isMenuOpen }">
        <ul class="nav-links">
          <li>
            <NuxtLink to="/" class="nav-link">
              <i class="fas fa-home"></i>
              <span>Inicio</span>
              <span class="nav-link-indicator"></span>
            </NuxtLink>
          </li>
          <li>
            <NuxtLink to="/contenido" class="nav-link">
              <i class="fas fa-book-open"></i>
              <span>Contenido</span>
              <span class="nav-link-indicator"></span>
            </NuxtLink>
          </li>
          <li>
            <NuxtLink to="/quiz" class="nav-link">
              <i class="fas fa-question-circle"></i>
              <span>Quiz</span>
              <span class="nav-link-indicator"></span>
            </NuxtLink>
          </li>
        </ul>
      </div>

      <button class="navbar-toggle" @click="toggleMenu" aria-label="Toggle menu">
        <span></span>
        <span></span>
        <span></span>
      </button>
    </div>
  </nav>
  <!-- Espaciador para compensar la navbar fija -->
  <div class="navbar-spacer"></div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

const isScrolled = ref(false)
const isMenuOpen = ref(false)

const handleScroll = () => {
  isScrolled.value = window.scrollY > 50
}

const toggleMenu = () => {
  isMenuOpen.value = !isMenuOpen.value
}

onMounted(() => {
  window.addEventListener('scroll', handleScroll)
})

onUnmounted(() => {
  window.removeEventListener('scroll', handleScroll)
})
</script>

<style scoped>
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css');

.navbar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  background: linear-gradient(135deg, #2563eb, #3b82f6);
  padding: 0.8rem 0;
  transition: all 0.3s ease;
  border-radius: 10px;
}

/* Espaciador para compensar la navbar fija */
.navbar-spacer {
  height: 70px; /* Ajusta este valor según la altura de tu navbar */
}

.navbar-scrolled {
  background: rgba(37, 99, 235, 0.95);
  backdrop-filter: blur(10px);
  padding: 0.6rem 0;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.navbar-container {
  max-width: 1200px;
  width: 90%; /* Ajusta el ancho para alinear con el contenido */
  margin: 0 auto;
  padding: 0 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.navbar-logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: white;
  font-size: 1.25rem;
  font-weight: 700;
}

.logo-text {
  background: rgba(255, 255, 255, 0.2);
  padding: 0.3rem 0.6rem;
  border-radius: 8px;
  font-family: 'Courier New', monospace;
  animation: pulse 2s infinite;
}

.logo-name {
  background: linear-gradient(to right, #fff, #e0e7ff);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.nav-links {
  display: flex;
  gap: 1.5rem;
  list-style: none;
  margin: 0;
  padding: 0;
}

.nav-link {
  color: white;
  text-decoration: none;
  font-weight: 500;
  font-size: 0.95rem;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  position: relative;
  transition: all 0.3s ease;
}

.nav-link i {
  font-size: 1.1rem;
  transition: transform 0.3s ease;
}

.nav-link:hover {
  background: rgba(255, 255, 255, 0.1);
}

.nav-link:hover i {
  transform: translateY(-2px);
}

.nav-link-indicator {
  position: absolute;
  bottom: -2px;
  left: 50%;
  width: 0;
  height: 2px;
  background: white;
  transform: translateX(-50%);
  transition: width 0.3s ease;
}

.nav-link:hover .nav-link-indicator {
  width: 80%;
}

.router-link-active {
  background: rgba(255, 255, 255, 0.15);
}

.router-link-active .nav-link-indicator {
  width: 80%;
}

.navbar-toggle {
  display: none;
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.5rem;
  position: relative;
  z-index: 100;
}

.navbar-toggle span {
  display: block;
  width: 25px;
  height: 3px;
  background: white;
  margin: 5px 0;
  transition: all 0.3s ease;
}

@keyframes pulse {
  0% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.05);
    opacity: 0.8;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}

@media (max-width: 768px) {
  .navbar-container {
    width: 95%; /* Ajuste para móviles */
  }

  .navbar-menu {
    position: fixed;
    top: 0;
    right: -100%;
    width: 80%;
    height: 100vh;
    background: linear-gradient(135deg, #2563eb, #3b82f6);
    padding: 6rem 2rem 2rem;
    transition: right 0.3s ease;
  }

  .navbar-menu.active {
    right: 0;
  }

  .nav-links {
    flex-direction: column;
    gap: 1.5rem;
  }

  .navbar-toggle {
    display: block;
  }

  .active .navbar-toggle span:nth-child(1) {
    transform: rotate(45deg) translate(6px, 6px);
  }

  .active .navbar-toggle span:nth-child(2) {
    opacity: 0;
  }

  .active .navbar-toggle span:nth-child(3) {
    transform: rotate(-45deg) translate(6px, -6px);
  }
}

/* Animaciones */
@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.nav-link {
  animation: slideIn 0.3s ease forwards;
}

.nav-links li:nth-child(1) .nav-link { animation-delay: 0.1s; }
.nav-links li:nth-child(2) .nav-link { animation-delay: 0.2s; }
.nav-links li:nth-child(3) .nav-link { animation-delay: 0.3s; }
</style>