<template>
  <div class="web-dev-container">
    <NavBar />
    
    <section class="hero animate-gradient">
      <h1 class="text-reveal">Desarrollo Web: Construyendo el Futuro Digital</h1>
      <p class="fade-in">Descubre cómo transformar ideas creativas en experiencias web interactivas y funcionales</p>
    </section>
    
    <section class="content">
      <div class="section web-process">
        <h2 class="section-title">Proceso de Desarrollo Web</h2>
        <div class="process-grid">
          <div class="process-step slide-in">
            <div class="icon">🎨</div>
            <h3>Diseño UX/UI</h3>
            <p class="p1">proceso que combina el diseño de la experiencia de usuario (UX) y el diseño de la interfaz de usuario (UI) para crear productos y servicios intuitivos y fáciles de usar. 
El diseño UX se centra en la usabilidad y la funcionalidad de un producto o servicio, considerando al usuario como el centro de la experiencia. El diseño UI se enfoca en la creación de una interfaz visual que se ajuste a la personalidad de la marca. </p>
          </div>
          <div class="process-step slide-in">
            <div class="icon">💻</div>
            <h3>Desarrollo Frontend</h3>
            <p class="p2">Es la creación de la interfaz visual de una aplicación web o sitio web, con el objetivo de que los usuarios puedan interactuar con ella:
              <ul>
                <li class="l1"  >Se encarga de la parte visual e interactiva de la aplicación</li>
                <li class="l2"  >Se basa en lenguajes web como HTML, CSS y JavaScript</li>
                <li class="l3" >ncluye la traducción de diseños en código y la implementación de funcionalidades interactivas</li>
                <li class="l4" >Los desarrolladores de front-end se encargan de que los elementos sean visualmente atractivos y fáciles de usa</li>
              </ul>
            </p>
          </div>
          <div class="process-step slide-in">
            <div class="icon">🔧</div>
            <h3>Desarrollo Backend</h3>
            <p> Es la parte del desarrollo de un sitio web, aplicación o programa que se encarga de la lógica de la parte del servidor:
              <ul>
                <li class="l5">Se encarga de la programación de los componentes que hacen que el sitio funcione correctamente
                </li>
                <li class="l5">Es la parte lógica que el usuario no ve, pero que es fundamental para que los elementos se visualicen correctamente</li>
                <li class="l5">Se trabaja con diferentes lenguajes de programación como Java, PHP, MySQL, etcétera</li>
              </ul>
            </p>
          </div>
          <div class="process-step slide-in">
            <div class="icon">🚀</div>
            <h3>Despliegue y Mantenimiento</h3>
            <p class="p3">El despliegue de una aplicación web es el proceso de hacer que una aplicación desarrollada localmente esté disponible para los usuarios finales. El mantenimiento web es un conjunto de tareas que se realizan para mantener y mejorar el rendimiento de un sitio web</p>
          </div>
        </div>
      </div>
      
      <div class="section technologies">
        <h2 class="section-title">Tecnologías Modernas</h2>
        <div class="tech-stack">
          <div class="tech-card">
            <h3>Frameworks Frontend</h3>
            <ul>
              <li>React</li>
              <li>Vue.js</li>
              <li>Angular</li>
              <li>Svelte</li>
            </ul>
          </div>
          <div class="tech-card">
            <h3>Backend</h3>
            <ul>
              <li>Node.js</li>
              <li>Django</li>
              <li>Ruby on Rails</li>
              <li>Laravel</li>
            </ul>
          </div>
          <div class="tech-card">
            <h3>Herramientas de Desarrollo</h3>
            <ul>
              <li>VS Code</li>
              <li>Git/GitHub</li>
              <li>Docker</li>
              <li>Webpack</li>
            </ul>
          </div>
        </div>
      </div>
      
      <div class="section career-paths">
        <h2 class="section-title">Rutas Profesionales</h2>
        <div class="career-grid">
          <div class="career-card">
            <h3>Frontend Developer</h3>
            <p>Especializado en interfaces de usuario y experiencia interactiva</p>
          </div>
          <div class="career-card">
            <h3>Backend Developer</h3>
            <p>Enfocado en lógica de servidor, bases de datos y rendimiento</p>
          </div>
          <div class="career-card">
            <h3>Full Stack Developer</h3>
            <p>Dominio tanto de frontend como de backend</p>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import NavBar from '~/components/NavBar.vue'
</script>

<style scoped>

.p1, .p2,.p3 {
  text-align: left
}

.l1,.l2,.l3,.l4,.l5 {
  text-align: left
}
.web-dev-container {
  font-family: "poppins";
  background: linear-gradient(135deg, #f5f7fa, #e9ecef);
  
}

.hero {
  background: linear-gradient(45deg, #6a11cb, #2575fc);
  color: white;
  text-align: center;
  padding: 80px 20px;
  clip-path: polygon(0 0, 100% 0, 100% 85%, 0 100%);
  position: relative;
  overflow: hidden;

}

.hero h1 {
  font-size: 3rem;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.process-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 25px;
}

.process-step {
  background: white;
  border-radius: 15px;
  padding: 25px;
  text-align: center;
  box-shadow: 0 15px 30px rgba(0,0,0,0.1);
  transition: all 0.3s ease;
}

.process-step:hover {
  transform: translateY(-10px);
  box-shadow: 0 20px 40px rgba(0,0,0,0.15);
}

.section-title {
  color: #6a11cb;
  text-align: center;
  position: relative;
  margin-bottom: 40px;
}

.section-title::after {
  content: '';
  position: absolute;
  bottom: -10px;
  left: 50%;
  transform: translateX(-50%);
  width: 100px;
  height: 4px;
  background: #6a11cb;
}

.tech-stack {
  display: flex;
  justify-content: space-between;
  gap: 20px;
}

.tech-card {
  flex: 1;
  background: white;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

.career-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

.career-card {
  background: white;
  border-radius: 10px;
  padding: 25px;
  text-align: center;
  box-shadow: 0 10px 20px rgba(0,0,0,0.1);
  transition: transform 0.3s ease;
}

.career-card:hover {
  transform: scale(1.05);
}
</style>

  