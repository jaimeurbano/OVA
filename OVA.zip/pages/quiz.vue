<template>
  <div class="quiz-wrapper">
    <NavBar />
    <section class="quiz-container">
      <div class="quiz-header">
        <h1>Quiz: Introducción al Desarrollo Web</h1>
        <p class="quiz-description">
          Pon a prueba tus conocimientos sobre desarrollo web respondiendo estas preguntas.
          ¡Demuestra lo que sabes!
        </p>
      </div>
      
      <div class="progress-bar">
        <div 
          class="progress-fill" 
          :style="{ width: `${(selectedAnswers.filter(a => a !== null).length / questions.length) * 100}%` }"
        ></div>
        <span class="progress-text">
          {{ selectedAnswers.filter(a => a !== null).length }} de {{ questions.length }} respondidas
        </span>
      </div>
      
      <div class="questions-wrapper">
        <div 
          v-for="(question, index) in questions" 
          :key="index" 
          class="question-card"
          :class="{ 'answered': selectedAnswers[index] !== null }"
        >
          <div class="question-number">Pregunta {{ index + 1 }}</div>
          <h3>{{ question.text }}</h3>
          <div class="options">
            <label
              v-for="(option, i) in question.options"
              :key="i"
              class="option-label"
              :class="{
                'selected': selectedAnswers[index] === i,
                'correct': showResults && i === question.correctOption,
                'incorrect': showResults && selectedAnswers[index] === i && i !== question.correctOption
              }"
            >
              <input 
                type="radio" 
                :name="'question-' + index" 
                :value="i" 
                v-model="selectedAnswers[index]" 
                :disabled="showResults"
              />
              <span class="option-text">{{ option }}</span>
              <span 
                v-if="showResults && i === question.correctOption" 
                class="check-icon"
              >✓</span>
            </label>
          </div>
        </div>
      </div>

      <div class="quiz-actions">
        <button 
          class="action-btn check-btn" 
          @click="checkAnswers"
          :disabled="selectedAnswers.includes(null) || showResults"
        >
          Verificar Respuestas
        </button>
        <button class="action-btn reset-btn" @click="resetQuiz">
          Reiniciar Quiz
        </button>
      </div>

      <div v-if="showResults" class="results-container">
        <div class="results-header">
          <h2>Resultados Finales</h2>
          <div class="score-circle">
            <span class="score-number">{{ correctAnswersCount }}</span>
            <span class="score-total">/{{ questions.length }}</span>
          </div>
        </div>
        <p class="results-message">
          {{ getResultMessage(correctAnswersCount) }}
        </p>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import NavBar from '~/components/NavBar.vue'

const questions = [
    {
      text: '¿Qué define la estructura de un sitio web?',
      options: ['CSS', 'HTML', 'JavaScript', 'PHP'],
      correctOption: 1,
    },
    {
      text: '¿Qué lenguaje se utiliza para estilizar una página web?',
      options: ['HTML', 'Python', 'CSS', 'SQL'],
      correctOption: 2,
    },
    {
      text: '¿Qué permite JavaScript en una página web?',
      options: ['Estructurar contenido', 'Estilizar elementos', 'Añadir interactividad', 'Crear servidores'],
      correctOption: 2,
    },
    {
      text: '¿Qué es el diseño responsivo?',
      options: [
        'Diseño para dispositivos móviles',
        'Diseño que se adapta a diferentes tamaños de pantalla',
        'Diseño avanzado de bases de datos',
        'Diseño exclusivo para escritorio',
      ],
      correctOption: 1,
    },
    {
      text: '¿Cuál de estas herramientas es un editor de código?',
      options: ['VS Code', 'MySQL', 'Apache', 'GitHub'],
      correctOption: 0,
    },
    {
      text: '¿Qué es el frontend en el desarrollo web?',
      options: [
        'La lógica del servidor',
        'El diseño y la interacción visible por el usuario',
        'El almacenamiento de datos',
        'La configuración del dominio',
      ],
      correctOption: 1,
    },
    {
      text: '¿Qué es una práctica recomendada en desarrollo web?',
      options: [
        'Ignorar la accesibilidad',
        'Optimizar para dispositivos móviles',
        'Evitar usar frameworks',
        'No usar control de versiones',
      ],
      correctOption: 1,
    },
    {
      text: '¿Qué framework es popular para desarrollo frontend?',
      options: ['Vue.js', 'Django', 'Node.js', 'Laravel'],
      correctOption: 0,
    },
    {
      text: '¿Qué es Git?',
      options: [
        'Un lenguaje de programación',
        'Un sistema de control de versiones',
        'Un servidor web',
        'Una base de datos',
      ],
      correctOption: 1,
    },
    {
      text: '¿Qué significa "Full-stack"?',
      options: [
        'Diseño de bases de datos',
        'Especialista en frontend',
        'Especialista en backend',
        'Combinación de frontend y backend',
      ],
      correctOption: 3,
    },
  ]

const selectedAnswers = ref(Array(questions.length).fill(null))
const showResults = ref(false)
const correctAnswersCount = ref(0)

const checkAnswers = () => {
  correctAnswersCount.value = selectedAnswers.value.reduce(
    (count, answer, index) => count + (answer === questions[index].correctOption ? 1 : 0),
    0
  )
  showResults.value = true
}

const resetQuiz = () => {
  selectedAnswers.value = Array(questions.length).fill(null)
  showResults.value = false
  correctAnswersCount.value = 0
  window.scrollTo({ top: 0, behavior: 'smooth' })
}

const getResultMessage = (score) => {
  if (score === questions.length) return '¡Excelente! ¡Has demostrado ser un experto en desarrollo web!'
  if (score >= questions.length * 0.8) return '¡Muy bien! Tienes un gran conocimiento del desarrollo web.'
  if (score >= questions.length * 0.6) return 'Buen trabajo. Sigue aprendiendo para mejorar.'
  return 'Continúa estudiando y practicando. ¡Tú puedes hacerlo mejor!'
}

const isCorrect = (index) => selectedAnswers.value[index] === questions[index].correctOption
</script>

<style scoped>
.quiz-wrapper {
  min-height: 100vh;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  padding: 20px;
}

.quiz-container {
  max-width: 800px;
  margin: 90px auto 20px;
  background: white;
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  padding: 30px;
}

.quiz-header {
  text-align: center;
  margin-bottom: 40px;
}

.quiz-header h1 {
  color: #2d3436;
  font-size: 2.5rem;
  margin-bottom: 15px;
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

.quiz-description {
  color: #636e72;
  font-size: 1.1rem;
  line-height: 1.6;
}

.progress-bar {
  height: 10px;
  background: #f0f0f0;
  border-radius: 5px;
  margin: 30px 0;
  position: relative;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  transition: width 0.3s ease;
}

.progress-text {
  position: absolute;
  right: 10px;
  top: -25px;
  font-size: 0.9rem;
  color: #636e72;
}

.questions-wrapper {
  display: flex;
  flex-direction: column;
  gap: 30px;
}

.question-card {
  background: white;
  border-radius: 15px;
  padding: 25px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease;
  border: 2px solid #f0f0f0;
}

.question-card:hover {
  transform: translateY(-5px);
}

.question-card.answered {
  border-color: #6a11cb;
}

.question-number {
  font-size: 0.9rem;
  color: #6a11cb;
  margin-bottom: 10px;
  font-weight: bold;
}

.question-card h3 {
  color: #2d3436;
  margin-bottom: 20px;
  font-size: 1.2rem;
  line-height: 1.4;
}

.options {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.option-label {
  display: flex;
  align-items: center;
  padding: 15px;
  border-radius: 10px;
  background: #f8f9fa;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
}

.option-label:hover {
  background: #f0f0f0;
}

.option-label.selected {
  background: #6a11cb15;
  border: 2px solid #6a11cb;
}

.option-label.correct {
  background: #00b89420;
  border: 2px solid #00b894;
}

.option-label.incorrect {
  background: #ff737320;
  border: 2px solid #ff7373;
}

.option-label input {
  display: none;
}

.option-text {
  margin-left: 10px;
  color: #2d3436;
  flex-grow: 1;
}

.check-icon {
  position: absolute;
  right: 15px;
  color: #00b894;
  font-weight: bold;
}

.quiz-actions {
  display: flex;
  gap: 20px;
  margin-top: 40px;
  justify-content: center;
}

.action-btn {
  padding: 12px 30px;
  border-radius: 25px;
  border: none;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.check-btn {
  background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
  color: white;
}

.check-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(106, 17, 203, 0.4);
}

.check-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
  transform: none;
}

.reset-btn {
  background: white;
  color: #ff7373;
  border: 2px solid #ff7373;
}

.reset-btn:hover {
  background: #ff7373;
  color: white;
}

.results-container {
  margin-top: 40px;
  padding: 30px;
  background: linear-gradient(135deg, #6a11cb10 0%, #2575fc10 100%);
  border-radius: 15px;
  text-align: center;
}

.results-header {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  margin-bottom: 20px;
}

.results-header h2 {
  color: #2d3436;
  font-size: 1.8rem;
}

.score-circle {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: white;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.score-number {
  font-size: 1.8rem;
  font-weight: bold;
  color: #6a11cb;
}

.score-total {
  font-size: 1rem;
  color: #636e72;
}

.results-message {
  font-size: 1.2rem;
  color: #2d3436;
  line-height: 1.6;
  margin-top: 20px;
}

@media (max-width: 768px) {
  .quiz-container {
    padding: 20px;
    margin-top: 70px;
  }

  .quiz-header h1 {
    font-size: 2rem;
  }

  .quiz-actions {
    flex-direction: column;
  }

  .action-btn {
    width: 100%;
  }
}
</style>
  
  